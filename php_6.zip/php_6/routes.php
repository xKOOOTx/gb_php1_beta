<?php

return [
  'home' => 'controller/HomeController.php',
    'security' => 'controller/SecurityController.php'
];
